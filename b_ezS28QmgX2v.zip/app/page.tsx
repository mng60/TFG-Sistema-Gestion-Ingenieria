"use client"

import { useState } from "react"
import LoginMockup1 from "@/components/login-mockups/mockup-1-particles"
import LoginMockup2 from "@/components/login-mockups/mockup-2-mesh-gradient"
import LoginMockup3 from "@/components/login-mockups/mockup-3-circuit"
import LoginMockup4 from "@/components/login-mockups/mockup-4-aurora"

const mockups = [
  { id: 1, name: "Partículas Flotantes", description: "Fondo con partículas animadas que flotan suavemente" },
  { id: 2, name: "Mesh Gradient", description: "Gradiente mesh animado con ondas fluidas" },
  { id: 3, name: "Circuito Digital", description: "Líneas de circuito animadas estilo tech" },
  { id: 4, name: "Aurora Boreal", description: "Efecto aurora con ondas de color" },
]

export default function LoginMockupsShowcase() {
  const [activeMockup, setActiveMockup] = useState(1)

  return (
    <div className="min-h-screen bg-[#050508]">
      {/* Selector de Mockups */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-[#0a0a0f]/90 backdrop-blur-xl border-b border-teal-500/20">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-xl font-bold text-white">
                <span className="text-teal-400">BLUEARC</span>ENERGY
              </h1>
              <p className="text-sm text-gray-400">Mockups Portal de Empleados - Login</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-500">Selecciona un diseño:</span>
            </div>
          </div>
          
          <div className="flex gap-3 overflow-x-auto pb-2">
            {mockups.map((mockup) => (
              <button
                key={mockup.id}
                onClick={() => setActiveMockup(mockup.id)}
                className={`flex-shrink-0 px-4 py-3 rounded-lg border transition-all duration-300 text-left ${
                  activeMockup === mockup.id
                    ? "bg-teal-500/20 border-teal-500 text-teal-400"
                    : "bg-[#111118] border-gray-800 text-gray-400 hover:border-teal-500/50 hover:text-teal-300"
                }`}
              >
                <div className="text-sm font-medium">{mockup.id}. {mockup.name}</div>
                <div className="text-xs opacity-70 mt-1">{mockup.description}</div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Contenedor del Mockup Activo */}
      <div className="pt-36">
        <div className="relative mx-auto max-w-6xl px-4">
          {/* Marco del mockup */}
          <div className="rounded-2xl overflow-hidden border border-teal-500/30 shadow-2xl shadow-teal-500/10">
            <div className="bg-[#0a0a0f] px-4 py-2 flex items-center gap-2 border-b border-gray-800">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500/80" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
                <div className="w-3 h-3 rounded-full bg-green-500/80" />
              </div>
              <div className="flex-1 mx-4">
                <div className="bg-[#1a1a24] rounded-md px-3 py-1 text-xs text-gray-500 text-center">
                  portal.bluearc-energy.com/login
                </div>
              </div>
            </div>
            
            {/* Mockup Content */}
            <div className="h-[600px] overflow-hidden">
              {activeMockup === 1 && <LoginMockup1 />}
              {activeMockup === 2 && <LoginMockup2 />}
              {activeMockup === 3 && <LoginMockup3 />}
              {activeMockup === 4 && <LoginMockup4 />}
            </div>
          </div>
          
          {/* Info del mockup activo */}
          <div className="mt-6 p-4 rounded-xl bg-[#0a0a0f] border border-gray-800">
            <h3 className="text-lg font-semibold text-teal-400 mb-2">
              Mockup {activeMockup}: {mockups[activeMockup - 1].name}
            </h3>
            <p className="text-gray-400 text-sm">
              {activeMockup === 1 && "Partículas sutiles que flotan en el fondo, creando una sensación de profundidad y movimiento sin distraer. Ideal para un look tecnológico pero elegante."}
              {activeMockup === 2 && "Gradientes mesh fluidos con colores teal/cyan que se mezclan orgánicamente. Un diseño moderno y sofisticado que transmite innovación."}
              {activeMockup === 3 && "Líneas de circuito animadas que recorren el panel derecho, reforzando la identidad de ingeniería y tecnología de la empresa."}
              {activeMockup === 4 && "Efecto aurora boreal con ondas de color que fluyen suavemente. Transmite energía limpia y conecta con la identidad de empresa energética."}
            </p>
          </div>
        </div>
      </div>
      
      <div className="h-20" />
    </div>
  )
}
