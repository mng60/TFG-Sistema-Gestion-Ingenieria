"use client"

import { useState } from "react"
import { Eye, EyeOff, Lock, Mail, Fingerprint } from "lucide-react"

// Aurora effect background
function AuroraBackground() {
  return (
    <div className="absolute inset-0 overflow-hidden">
      {/* Aurora waves */}
      <div className="absolute inset-0">
        <div 
          className="absolute w-full h-[200%] opacity-30"
          style={{
            background: `
              linear-gradient(180deg, 
                transparent 0%,
                rgba(13, 148, 136, 0.2) 20%,
                rgba(6, 182, 212, 0.3) 40%,
                rgba(20, 184, 166, 0.2) 60%,
                transparent 80%
              )
            `,
            animation: "auroraWave 8s ease-in-out infinite",
          }}
        />
        <div 
          className="absolute w-full h-[200%] opacity-20"
          style={{
            background: `
              linear-gradient(180deg, 
                transparent 10%,
                rgba(6, 182, 212, 0.3) 30%,
                rgba(13, 148, 136, 0.2) 50%,
                rgba(20, 184, 166, 0.3) 70%,
                transparent 90%
              )
            `,
            animation: "auroraWave 12s ease-in-out infinite reverse",
            animationDelay: "-4s",
          }}
        />
        <div 
          className="absolute w-full h-[200%] opacity-25"
          style={{
            background: `
              linear-gradient(180deg, 
                transparent 5%,
                rgba(20, 184, 166, 0.2) 25%,
                rgba(13, 148, 136, 0.4) 45%,
                rgba(6, 182, 212, 0.2) 65%,
                transparent 85%
              )
            `,
            animation: "auroraWave 10s ease-in-out infinite",
            animationDelay: "-2s",
          }}
        />
      </div>
      
      {/* Stars */}
      <div className="absolute inset-0">
        {[...Array(30)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              opacity: Math.random() * 0.5 + 0.2,
              animation: `twinkle ${Math.random() * 3 + 2}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 2}s`,
            }}
          />
        ))}
      </div>
      
      <style jsx>{`
        @keyframes auroraWave {
          0%, 100% { transform: translateY(0) scaleY(1); }
          50% { transform: translateY(-10%) scaleY(1.1); }
        }
        @keyframes twinkle {
          0%, 100% { opacity: 0.2; transform: scale(1); }
          50% { opacity: 0.8; transform: scale(1.2); }
        }
      `}</style>
    </div>
  )
}

export default function LoginMockup4() {
  const [showPassword, setShowPassword] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [focusedField, setFocusedField] = useState<string | null>(null)

  return (
    <div className="relative h-full w-full bg-[#020208] overflow-hidden">
      <AuroraBackground />
      
      {/* Contenido central */}
      <div className="relative z-10 h-full flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          {/* Logo y título */}
          <div className="text-center mb-10">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-teal-500/20 to-cyan-500/20 border border-teal-500/30 mb-6 backdrop-blur-sm">
              <Fingerprint className="w-8 h-8 text-teal-400" />
            </div>
            <h1 className="text-2xl font-bold mb-2">
              <span className="text-teal-400">BLUEARC</span>
              <span className="text-white">ENERGY</span>
            </h1>
            <p className="text-gray-500 text-sm">Portal de Empleados</p>
          </div>

          {/* Form Card */}
          <div className="relative">
            {/* Glow effect */}
            <div className="absolute -inset-1 bg-gradient-to-r from-teal-500/20 via-cyan-500/20 to-teal-500/20 rounded-3xl blur-xl opacity-50" />
            
            <div className="relative bg-[#0a0a14]/80 backdrop-blur-2xl rounded-3xl p-8 border border-white/5">
              <h2 className="text-xl font-semibold text-white mb-1 text-center">Bienvenido de nuevo</h2>
              <p className="text-gray-500 text-sm mb-8 text-center">Accede a tu cuenta para continuar</p>
              
              <div className="space-y-4">
                {/* Email */}
                <div className={`relative transition-all duration-300 ${focusedField === 'email' ? 'scale-[1.02]' : ''}`}>
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">
                    <Mail className="w-5 h-5" />
                  </div>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    onFocus={() => setFocusedField('email')}
                    onBlur={() => setFocusedField(null)}
                    placeholder="Email corporativo"
                    className="w-full bg-[#12121c] border border-gray-800/50 rounded-2xl pl-12 pr-4 py-4 text-white placeholder-gray-500 focus:border-teal-500/50 focus:ring-2 focus:ring-teal-500/20 transition-all outline-none"
                  />
                </div>

                {/* Password */}
                <div className={`relative transition-all duration-300 ${focusedField === 'password' ? 'scale-[1.02]' : ''}`}>
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">
                    <Lock className="w-5 h-5" />
                  </div>
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    onFocus={() => setFocusedField('password')}
                    onBlur={() => setFocusedField(null)}
                    placeholder="Contraseña"
                    className="w-full bg-[#12121c] border border-gray-800/50 rounded-2xl pl-12 pr-14 py-4 text-white placeholder-gray-500 focus:border-teal-500/50 focus:ring-2 focus:ring-teal-500/20 transition-all outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-teal-400 transition-colors p-1"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>

                {/* Options row */}
                <div className="flex items-center justify-between pt-2">
                  <label className="flex items-center gap-2 cursor-pointer group">
                    <div className="w-5 h-5 rounded-md bg-[#12121c] border border-gray-700 group-hover:border-teal-500/50 flex items-center justify-center transition-colors">
                      <div className="w-3 h-3 rounded-sm bg-teal-500 scale-0 group-hover:scale-50 transition-transform" />
                    </div>
                    <span className="text-sm text-gray-400 group-hover:text-gray-300 transition-colors">Mantener sesión</span>
                  </label>
                  <a href="#" className="text-sm text-teal-400 hover:text-teal-300 transition-colors">
                    ¿Olvidaste tu contraseña?
                  </a>
                </div>

                {/* Submit */}
                <button className="w-full mt-4 relative group">
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-teal-500 to-cyan-500 rounded-2xl blur opacity-60 group-hover:opacity-100 transition duration-300" />
                  <div className="relative bg-gradient-to-r from-teal-500 to-teal-600 text-white font-semibold py-4 rounded-2xl transition-all hover:from-teal-400 hover:to-teal-500 flex items-center justify-center gap-2">
                    Acceder al Sistema
                  </div>
                </button>
              </div>
              
              {/* Divider */}
              <div className="flex items-center gap-4 my-8">
                <div className="flex-1 h-px bg-gradient-to-r from-transparent via-gray-700 to-transparent" />
                <span className="text-xs text-gray-600 uppercase tracking-wider">SSO</span>
                <div className="flex-1 h-px bg-gradient-to-r from-transparent via-gray-700 to-transparent" />
              </div>
              
              {/* SSO options */}
              <div className="grid grid-cols-2 gap-3">
                <button className="bg-[#12121c] hover:bg-[#16161f] border border-gray-800/50 hover:border-teal-500/30 py-3 rounded-xl transition-all text-sm text-gray-400 hover:text-white flex items-center justify-center gap-2">
                  <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z"/>
                  </svg>
                  GitHub
                </button>
                <button className="bg-[#12121c] hover:bg-[#16161f] border border-gray-800/50 hover:border-teal-500/30 py-3 rounded-xl transition-all text-sm text-gray-400 hover:text-white flex items-center justify-center gap-2">
                  <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                  </svg>
                  Google
                </button>
              </div>
            </div>
          </div>
          
          {/* Footer */}
          <p className="text-center text-gray-600 text-xs mt-8">
            Al acceder, aceptas nuestras políticas de seguridad corporativas
          </p>
        </div>
      </div>
    </div>
  )
}
