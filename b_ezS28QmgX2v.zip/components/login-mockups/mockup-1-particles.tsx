"use client"

import { useState, useEffect } from "react"
import { Eye, EyeOff, Zap } from "lucide-react"

// Partículas flotantes animadas
function FloatingParticles() {
  return (
    <div className="absolute inset-0 overflow-hidden">
      {[...Array(50)].map((_, i) => (
        <div
          key={i}
          className="absolute rounded-full bg-teal-400/30"
          style={{
            width: Math.random() * 4 + 1 + "px",
            height: Math.random() * 4 + 1 + "px",
            left: Math.random() * 100 + "%",
            top: Math.random() * 100 + "%",
            animation: `floatParticle ${Math.random() * 10 + 15}s linear infinite`,
            animationDelay: `-${Math.random() * 20}s`,
          }}
        />
      ))}
      <style jsx>{`
        @keyframes floatParticle {
          0%, 100% {
            transform: translateY(0) translateX(0);
            opacity: 0;
          }
          10% {
            opacity: 1;
          }
          90% {
            opacity: 1;
          }
          100% {
            transform: translateY(-100vh) translateX(50px);
            opacity: 0;
          }
        }
      `}</style>
    </div>
  )
}

// Líneas de conexión animadas
function ConnectionLines() {
  return (
    <svg className="absolute inset-0 w-full h-full opacity-20">
      <defs>
        <linearGradient id="lineGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="transparent" />
          <stop offset="50%" stopColor="#2dd4bf" />
          <stop offset="100%" stopColor="transparent" />
        </linearGradient>
      </defs>
      {[...Array(8)].map((_, i) => (
        <line
          key={i}
          x1={Math.random() * 100 + "%"}
          y1={Math.random() * 100 + "%"}
          x2={Math.random() * 100 + "%"}
          y2={Math.random() * 100 + "%"}
          stroke="url(#lineGrad1)"
          strokeWidth="1"
          className="animate-pulse"
          style={{ animationDelay: `${i * 0.5}s` }}
        />
      ))}
    </svg>
  )
}

export default function LoginMockup1() {
  const [showPassword, setShowPassword] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  return (
    <div className="relative h-full w-full bg-[#050508] flex">
      {/* Fondo animado con partículas */}
      <FloatingParticles />
      <ConnectionLines />
      
      {/* Panel izquierdo - Branding */}
      <div className="relative flex-1 flex flex-col justify-center items-center p-12">
        <div className="relative z-10 text-center">
          {/* Logo animado */}
          <div className="mb-8 relative">
            <div className="w-20 h-20 mx-auto rounded-2xl bg-gradient-to-br from-teal-500 to-teal-600 flex items-center justify-center relative overflow-hidden">
              <Zap className="w-10 h-10 text-white relative z-10" />
              <div className="absolute inset-0 bg-gradient-to-t from-teal-400/50 to-transparent animate-pulse" />
            </div>
            <div className="absolute -inset-4 bg-teal-500/20 blur-2xl rounded-full animate-pulse" />
          </div>
          
          <h1 className="text-4xl font-bold mb-2">
            <span className="text-teal-400">BLUEARC</span>
            <span className="text-white">ENERGY</span>
          </h1>
          <p className="text-gray-500 text-sm mb-8">Portal de Empleados</p>
          
          <div className="space-y-4 text-left max-w-xs mx-auto">
            {["Gestión de Proyectos", "Control de Clientes", "Equipos de Ingeniería"].map((item, i) => (
              <div key={i} className="flex items-center gap-3 text-gray-400">
                <div className="w-2 h-2 rounded-full bg-teal-500 animate-pulse" style={{ animationDelay: `${i * 0.3}s` }} />
                <span className="text-sm">{item}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Panel derecho - Formulario */}
      <div className="relative flex-1 flex items-center justify-center p-12">
        <div className="w-full max-w-md">
          {/* Card de login con efecto glassmorphism */}
          <div className="relative bg-[#0a0a12]/80 backdrop-blur-xl rounded-3xl p-8 border border-teal-500/20 shadow-2xl shadow-teal-500/5">
            {/* Glow effect */}
            <div className="absolute -inset-0.5 bg-gradient-to-r from-teal-500/20 to-cyan-500/20 rounded-3xl blur opacity-50" />
            
            <div className="relative z-10">
              <h2 className="text-2xl font-bold text-white mb-2">Bienvenido</h2>
              <p className="text-gray-500 text-sm mb-8">Accede a tu cuenta corporativa</p>
              
              <div className="space-y-6">
                {/* Email */}
                <div>
                  <label className="block text-xs font-medium text-gray-400 mb-2 uppercase tracking-wider">
                    Email Corporativo
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="nombre@bluearc-energy.com"
                    className="w-full bg-[#12121a] border border-gray-800 rounded-xl px-4 py-3.5 text-white placeholder-gray-600 focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition-all outline-none"
                  />
                </div>

                {/* Password */}
                <div>
                  <label className="block text-xs font-medium text-gray-400 mb-2 uppercase tracking-wider">
                    Contraseña
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-[#12121a] border border-gray-800 rounded-xl px-4 py-3.5 text-white placeholder-gray-600 focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition-all outline-none pr-12"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-teal-400 transition-colors"
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                {/* Remember & Forgot */}
                <div className="flex items-center justify-between text-sm">
                  <label className="flex items-center gap-2 text-gray-400 cursor-pointer">
                    <input type="checkbox" className="w-4 h-4 rounded bg-[#12121a] border-gray-700 text-teal-500 focus:ring-teal-500" />
                    Recordarme
                  </label>
                  <a href="#" className="text-teal-400 hover:text-teal-300 transition-colors">
                    ¿Olvidaste tu contraseña?
                  </a>
                </div>

                {/* Submit Button */}
                <button className="w-full bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-400 hover:to-teal-500 text-white font-semibold py-4 rounded-xl transition-all duration-300 shadow-lg shadow-teal-500/25 hover:shadow-teal-500/40 hover:scale-[1.02] active:scale-[0.98]">
                  Acceder al Sistema
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
