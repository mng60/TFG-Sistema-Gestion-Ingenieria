"use client"

import { useState } from "react"
import { Eye, EyeOff, ChevronRight, Shield, Cpu } from "lucide-react"

// Animated circuit lines
function CircuitBackground() {
  return (
    <div className="absolute inset-0 overflow-hidden opacity-40">
      <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="circuitGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="transparent">
              <animate attributeName="stop-color" values="transparent;#2dd4bf;transparent" dur="3s" repeatCount="indefinite" />
            </stop>
            <stop offset="50%" stopColor="#2dd4bf">
              <animate attributeName="stop-color" values="#2dd4bf;transparent;#2dd4bf" dur="3s" repeatCount="indefinite" />
            </stop>
            <stop offset="100%" stopColor="transparent">
              <animate attributeName="stop-color" values="transparent;#2dd4bf;transparent" dur="3s" repeatCount="indefinite" />
            </stop>
          </linearGradient>
        </defs>
        
        {/* Horizontal lines */}
        {[100, 200, 300, 400, 500].map((y, i) => (
          <g key={`h-${i}`}>
            <line x1="0" y1={y} x2="100%" y2={y} stroke="#1a1a2e" strokeWidth="1" />
            <line 
              x1="0" y1={y} x2="100%" y2={y} 
              stroke="url(#circuitGrad)" 
              strokeWidth="2"
              strokeDasharray="100 200"
              style={{ animation: `dashMove ${8 + i * 2}s linear infinite` }}
            />
          </g>
        ))}
        
        {/* Vertical lines */}
        {[150, 350, 550, 750].map((x, i) => (
          <g key={`v-${i}`}>
            <line x1={x} y1="0" x2={x} y2="100%" stroke="#1a1a2e" strokeWidth="1" />
            <line 
              x1={x} y1="0" x2={x} y2="100%" 
              stroke="url(#circuitGrad)" 
              strokeWidth="2"
              strokeDasharray="80 150"
              style={{ animation: `dashMoveVertical ${10 + i * 1.5}s linear infinite` }}
            />
          </g>
        ))}
        
        {/* Connection nodes */}
        {[[150, 200], [350, 300], [550, 400], [750, 100], [350, 500]].map(([x, y], i) => (
          <circle 
            key={`node-${i}`}
            cx={x} cy={y} r="4" 
            fill="#0a0a10" 
            stroke="#2dd4bf" 
            strokeWidth="2"
            className="animate-pulse"
            style={{ animationDelay: `${i * 0.5}s` }}
          />
        ))}
      </svg>
      
      <style jsx>{`
        @keyframes dashMove {
          to { stroke-dashoffset: -1000; }
        }
        @keyframes dashMoveVertical {
          to { stroke-dashoffset: -800; }
        }
      `}</style>
    </div>
  )
}

export default function LoginMockup3() {
  const [showPassword, setShowPassword] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  return (
    <div className="relative h-full w-full bg-[#05050a] flex">
      <CircuitBackground />
      
      {/* Panel izquierdo - Logo y features */}
      <div className="relative z-10 w-1/2 flex flex-col justify-between p-12">
        {/* Header */}
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-teal-500 to-cyan-500 flex items-center justify-center">
              <Cpu className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold">
                <span className="text-teal-400">BLUEARC</span>
                <span className="text-gray-300">ENERGY</span>
              </h1>
            </div>
          </div>
        </div>
        
        {/* Main content */}
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-teal-500/10 border border-teal-500/30 rounded-full text-teal-400 text-xs mb-6">
            <Shield className="w-3.5 h-3.5" />
            Sistema Seguro 256-bit
          </div>
          <h2 className="text-5xl font-bold text-white mb-4 leading-tight">
            Portal de<br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-cyan-400">
              Empleados
            </span>
          </h2>
          <p className="text-gray-500 text-lg max-w-md">
            Accede a la plataforma de gestión interna de proyectos, clientes y equipos de ingeniería.
          </p>
        </div>
        
        {/* Footer stats */}
        <div className="flex gap-8">
          {[
            { value: "99.9%", label: "Uptime" },
            { value: "24/7", label: "Soporte" },
            { value: "2FA", label: "Auth" },
          ].map((stat, i) => (
            <div key={i}>
              <div className="text-2xl font-bold text-teal-400">{stat.value}</div>
              <div className="text-xs text-gray-600 uppercase tracking-wider">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Panel derecho - Formulario */}
      <div className="relative z-10 w-1/2 flex items-center justify-center p-12">
        <div className="w-full max-w-sm">
          {/* Form container */}
          <div className="bg-[#0a0a12] border border-gray-800/80 rounded-2xl p-8 shadow-2xl">
            <h3 className="text-xl font-semibold text-white mb-1">Iniciar Sesión</h3>
            <p className="text-gray-500 text-sm mb-8">Ingresa tus credenciales corporativas</p>
            
            <div className="space-y-5">
              {/* Email */}
              <div>
                <label className="block text-xs text-gray-500 mb-2">EMAIL CORPORATIVO</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="usuario@bluearc-energy.com"
                  className="w-full bg-[#08080c] border border-gray-800 rounded-xl px-4 py-3 text-white text-sm placeholder-gray-600 focus:border-teal-500 focus:ring-1 focus:ring-teal-500/20 transition-all outline-none"
                />
              </div>

              {/* Password */}
              <div>
                <label className="block text-xs text-gray-500 mb-2">CONTRASEÑA</label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-[#08080c] border border-gray-800 rounded-xl px-4 py-3 text-white text-sm placeholder-gray-600 focus:border-teal-500 focus:ring-1 focus:ring-teal-500/20 transition-all outline-none pr-12"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-600 hover:text-teal-400 transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Options */}
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 text-sm text-gray-500 cursor-pointer">
                  <div className="w-4 h-4 rounded border border-gray-700 bg-[#08080c] flex items-center justify-center">
                    <div className="w-2 h-2 rounded-sm bg-teal-500 hidden" />
                  </div>
                  Recordarme
                </label>
                <a href="#" className="text-sm text-teal-400 hover:text-teal-300 transition-colors">
                  Recuperar acceso
                </a>
              </div>

              {/* Submit */}
              <button className="group w-full bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-400 hover:to-teal-500 text-white font-medium py-3.5 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-teal-500/20">
                Acceder al Sistema
                <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              </button>
            </div>
            
            {/* Divider */}
            <div className="flex items-center gap-4 my-6">
              <div className="flex-1 h-px bg-gray-800" />
              <span className="text-xs text-gray-600">o continúa con</span>
              <div className="flex-1 h-px bg-gray-800" />
            </div>
            
            {/* SSO Button */}
            <button className="w-full bg-[#08080c] hover:bg-[#0c0c14] border border-gray-800 text-gray-400 hover:text-white py-3 rounded-xl transition-all text-sm">
              Inicio de sesión único (SSO)
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
