"use client"

import { useState } from "react"
import { Eye, EyeOff, ArrowRight, Sparkles } from "lucide-react"

// Mesh gradient animado
function MeshGradientBackground() {
  return (
    <div className="absolute inset-0 overflow-hidden">
      {/* Blob 1 */}
      <div 
        className="absolute w-[600px] h-[600px] rounded-full opacity-30 blur-[100px]"
        style={{
          background: "radial-gradient(circle, #0d9488 0%, transparent 70%)",
          top: "-10%",
          right: "-10%",
          animation: "blob1 20s ease-in-out infinite",
        }}
      />
      {/* Blob 2 */}
      <div 
        className="absolute w-[500px] h-[500px] rounded-full opacity-20 blur-[80px]"
        style={{
          background: "radial-gradient(circle, #06b6d4 0%, transparent 70%)",
          bottom: "10%",
          left: "20%",
          animation: "blob2 25s ease-in-out infinite",
        }}
      />
      {/* Blob 3 */}
      <div 
        className="absolute w-[400px] h-[400px] rounded-full opacity-25 blur-[60px]"
        style={{
          background: "radial-gradient(circle, #14b8a6 0%, transparent 70%)",
          top: "40%",
          right: "30%",
          animation: "blob3 18s ease-in-out infinite",
        }}
      />
      <style jsx>{`
        @keyframes blob1 {
          0%, 100% { transform: translate(0, 0) scale(1); }
          33% { transform: translate(-50px, 50px) scale(1.1); }
          66% { transform: translate(50px, -30px) scale(0.9); }
        }
        @keyframes blob2 {
          0%, 100% { transform: translate(0, 0) scale(1); }
          33% { transform: translate(60px, -40px) scale(1.15); }
          66% { transform: translate(-40px, 60px) scale(0.85); }
        }
        @keyframes blob3 {
          0%, 100% { transform: translate(0, 0) scale(1); }
          33% { transform: translate(-30px, -50px) scale(0.95); }
          66% { transform: translate(40px, 40px) scale(1.05); }
        }
      `}</style>
    </div>
  )
}

// Grid pattern
function GridPattern() {
  return (
    <div 
      className="absolute inset-0 opacity-[0.03]"
      style={{
        backgroundImage: `
          linear-gradient(to right, #2dd4bf 1px, transparent 1px),
          linear-gradient(to bottom, #2dd4bf 1px, transparent 1px)
        `,
        backgroundSize: "60px 60px",
      }}
    />
  )
}

export default function LoginMockup2() {
  const [showPassword, setShowPassword] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isHovered, setIsHovered] = useState(false)

  return (
    <div className="relative h-full w-full bg-[#030306] overflow-hidden">
      <MeshGradientBackground />
      <GridPattern />
      
      {/* Contenido centrado */}
      <div className="relative z-10 h-full flex items-center justify-center p-8">
        <div className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-2 gap-0">
          
          {/* Panel izquierdo - Formulario */}
          <div className="bg-[#0a0a10]/90 backdrop-blur-2xl p-10 rounded-l-3xl border-l border-t border-b border-teal-500/10">
            <div className="mb-8">
              <div className="flex items-center gap-2 mb-6">
                <Sparkles className="w-5 h-5 text-teal-400" />
                <span className="text-teal-400 text-sm font-medium">BLUEARC ENERGY</span>
              </div>
              <h2 className="text-3xl font-bold text-white mb-2">Inicio de Sesión</h2>
              <p className="text-gray-500">Sistema de Gestión Interno</p>
            </div>

            <div className="space-y-5">
              {/* Email */}
              <div className="group">
                <label className="block text-xs font-medium text-gray-500 mb-2 group-focus-within:text-teal-400 transition-colors">
                  EMAIL CORPORATIVO
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="tu.email@bluearc-energy.com"
                  className="w-full bg-[#08080c] border-2 border-gray-800/50 rounded-2xl px-5 py-4 text-white placeholder-gray-600 focus:border-teal-500/50 focus:bg-[#0a0a10] transition-all outline-none"
                />
              </div>

              {/* Password */}
              <div className="group">
                <label className="block text-xs font-medium text-gray-500 mb-2 group-focus-within:text-teal-400 transition-colors">
                  CONTRASEÑA
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••"
                    className="w-full bg-[#08080c] border-2 border-gray-800/50 rounded-2xl px-5 py-4 text-white placeholder-gray-600 focus:border-teal-500/50 focus:bg-[#0a0a10] transition-all outline-none pr-14"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-5 top-1/2 -translate-y-1/2 text-gray-600 hover:text-teal-400 transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {/* Forgot password */}
              <div className="text-right">
                <a href="#" className="text-sm text-gray-500 hover:text-teal-400 transition-colors">
                  ¿Olvidaste tu contraseña?
                </a>
              </div>

              {/* Submit */}
              <button 
                className="group w-full bg-teal-500 hover:bg-teal-400 text-black font-semibold py-4 rounded-2xl transition-all duration-300 flex items-center justify-center gap-2"
                onMouseEnter={() => setIsHovered(true)}
                onMouseLeave={() => setIsHovered(false)}
              >
                Acceder al Portal
                <ArrowRight className={`w-5 h-5 transition-transform duration-300 ${isHovered ? "translate-x-1" : ""}`} />
              </button>
            </div>
          </div>

          {/* Panel derecho - Decorativo */}
          <div className="relative bg-gradient-to-br from-teal-600/20 to-cyan-600/10 backdrop-blur-xl p-10 rounded-r-3xl border-r border-t border-b border-teal-500/20 overflow-hidden flex items-center justify-center">
            {/* Círculos decorativos */}
            <div className="absolute w-40 h-40 rounded-full border border-teal-500/20 top-10 -right-10 animate-spin" style={{ animationDuration: "30s" }} />
            <div className="absolute w-60 h-60 rounded-full border border-teal-500/10 -bottom-20 -left-20 animate-spin" style={{ animationDuration: "45s", animationDirection: "reverse" }} />
            
            <div className="text-center relative z-10">
              <div className="w-24 h-24 mx-auto mb-6 rounded-3xl bg-gradient-to-br from-teal-400 to-cyan-500 flex items-center justify-center shadow-2xl shadow-teal-500/30">
                <span className="text-4xl font-bold text-white">BA</span>
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">Portal Interno</h3>
              <p className="text-teal-200/70 text-sm max-w-[200px] mx-auto">
                Gestión centralizada de proyectos, clientes y equipos
              </p>
              
              {/* Stats */}
              <div className="mt-8 grid grid-cols-2 gap-4">
                <div className="bg-[#0a0a10]/50 rounded-xl p-3 border border-teal-500/10">
                  <div className="text-2xl font-bold text-teal-400">247</div>
                  <div className="text-xs text-gray-500">Proyectos</div>
                </div>
                <div className="bg-[#0a0a10]/50 rounded-xl p-3 border border-teal-500/10">
                  <div className="text-2xl font-bold text-cyan-400">89</div>
                  <div className="text-xs text-gray-500">Equipos</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
