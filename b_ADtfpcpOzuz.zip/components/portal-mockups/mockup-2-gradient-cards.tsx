"use client"

import { useState } from "react"
import {
  LayoutDashboard,
  Users,
  FolderKanban,
  MessageSquare,
  UserCog,
  Ticket,
  LogOut,
  TrendingUp,
  Clock,
  CheckCircle2,
  Euro,
  Zap,
  Bell,
  Search,
  Settings,
  ArrowUpRight,
  MoreHorizontal,
} from "lucide-react"

// Grid de fondo animado
function AnimatedGrid() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden opacity-30">
      <div className="absolute inset-0" style={{
        backgroundImage: `
          linear-gradient(rgba(45, 212, 191, 0.03) 1px, transparent 1px),
          linear-gradient(90deg, rgba(45, 212, 191, 0.03) 1px, transparent 1px)
        `,
        backgroundSize: '60px 60px',
      }} />
      {/* Glow spots */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
    </div>
  )
}

// Sidebar con borde neón y glow
function GlowSidebar({ isExpanded, setIsExpanded }: { isExpanded: boolean; setIsExpanded: (v: boolean) => void }) {
  const navItems = [
    { icon: LayoutDashboard, label: "Dashboard", active: true, badge: null },
    { icon: Users, label: "Clientes", active: false, badge: "3" },
    { icon: FolderKanban, label: "Proyectos", active: false, badge: null },
    { icon: MessageSquare, label: "Chat", active: false, badge: "5" },
    { icon: UserCog, label: "Usuarios", active: false, badge: null },
    { icon: Ticket, label: "Tickets", active: false, badge: "2" },
  ]

  return (
    <div
      className={`relative h-full bg-[#08080c] transition-all duration-300 ease-out flex flex-col ${
        isExpanded ? "w-72" : "w-20"
      }`}
      onMouseEnter={() => setIsExpanded(true)}
      onMouseLeave={() => setIsExpanded(false)}
    >
      {/* Borde neón con glow */}
      <div className="absolute top-0 right-0 w-[1px] h-full">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-teal-500/50 to-transparent" />
        <div className="absolute w-8 h-full bg-gradient-to-l from-teal-500/20 to-transparent -left-8" />
        {/* Luz que recorre */}
        <div className="absolute w-full bg-teal-400 shadow-lg shadow-teal-400/50 h-20 animate-scan" />
      </div>
      <style jsx>{`
        @keyframes scan {
          0%, 100% { top: -20%; opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { top: 100%; opacity: 0; }
        }
        .animate-scan {
          animation: scan 4s ease-in-out infinite;
        }
      `}</style>

      {/* Logo */}
      <div className="p-5">
        <div className="flex items-center gap-3">
          <div className="relative w-12 h-12 shrink-0">
            <div className="absolute inset-0 bg-gradient-to-br from-teal-400 to-cyan-500 rounded-xl" />
            <div className="absolute inset-0 bg-gradient-to-br from-teal-400 to-cyan-500 rounded-xl blur-lg opacity-50" />
            <div className="relative w-full h-full rounded-xl flex items-center justify-center">
              <Zap className="w-6 h-6 text-white" />
            </div>
          </div>
          <div className={`overflow-hidden transition-all duration-300 ${isExpanded ? "w-auto opacity-100" : "w-0 opacity-0"}`}>
            <h1 className="font-bold whitespace-nowrap">
              <span className="text-teal-400">BLUEARC</span>
              <span className="text-white">ENERGY</span>
            </h1>
            <p className="text-xs text-gray-600 whitespace-nowrap">Sistema de Gestión</p>
          </div>
        </div>
      </div>

      {/* Navegación */}
      <nav className="flex-1 py-6 px-3">
        <div className="space-y-2">
          {navItems.map((item, idx) => (
            <button
              key={idx}
              className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-xl transition-all duration-200 relative group ${
                item.active
                  ? "bg-gradient-to-r from-teal-500/20 to-transparent text-white"
                  : "text-gray-500 hover:bg-white/5 hover:text-gray-300"
              }`}
            >
              {item.active && (
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-gradient-to-b from-teal-400 to-cyan-400 rounded-r-full" />
              )}
              <item.icon className={`w-5 h-5 shrink-0 ${item.active ? "text-teal-400" : ""}`} />
              <span className={`whitespace-nowrap transition-all duration-300 flex-1 text-left ${isExpanded ? "opacity-100" : "opacity-0 w-0"}`}>
                {item.label}
              </span>
              {item.badge && isExpanded && (
                <span className="px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-400 text-xs font-medium">
                  {item.badge}
                </span>
              )}
            </button>
          ))}
        </div>
      </nav>

      {/* Usuario */}
      <div className="p-4 mx-3 mb-3 rounded-2xl bg-gradient-to-br from-white/5 to-transparent border border-gray-800/50">
        <div className="flex items-center gap-3">
          <div className="relative w-10 h-10 shrink-0">
            <div className="absolute inset-0 bg-gradient-to-br from-teal-400 to-cyan-500 rounded-full" />
            <div className="absolute inset-0.5 bg-[#08080c] rounded-full flex items-center justify-center">
              <span className="text-teal-400 font-bold text-sm">M</span>
            </div>
            <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-[#08080c]" />
          </div>
          <div className={`overflow-hidden transition-all duration-300 ${isExpanded ? "w-auto opacity-100" : "w-0 opacity-0"}`}>
            <p className="text-sm font-medium text-white whitespace-nowrap">Miguel Cárdenas</p>
            <p className="text-xs text-gray-500 whitespace-nowrap">Admin</p>
          </div>
          {isExpanded && (
            <button className="ml-auto p-2 rounded-lg hover:bg-white/10 text-gray-500 hover:text-red-400 transition-colors">
              <LogOut className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

// Card con borde gradiente
function GradientBorderCard({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`relative group ${className}`}>
      <div className="absolute inset-0 bg-gradient-to-br from-teal-500/30 via-transparent to-cyan-500/30 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity" />
      <div className="absolute inset-[1px] bg-[#0c0c14] rounded-2xl" />
      <div className="relative">
        {children}
      </div>
    </div>
  )
}

export default function PortalMockup2() {
  const [sidebarExpanded, setSidebarExpanded] = useState(false)

  const stats = [
    { icon: FolderKanban, label: "Proyectos Activos", value: "3", change: "+2 este mes", color: "teal" },
    { icon: Clock, label: "En Progreso", value: "1", change: "Sin cambios", color: "blue" },
    { icon: CheckCircle2, label: "Completados", value: "1", change: "+1 esta semana", color: "green" },
    { icon: Ticket, label: "Tickets", value: "0", change: "Todos resueltos", color: "orange" },
  ]

  const projects = [
    { name: "Renovación Sistema Eléctrico Industrial", client: "Industrias García S.A.", progress: 45, status: "Pendiente", budget: "127.086,30 €" },
    { name: "Instalación Eléctrica Edificio Central", client: "Constructora Martínez S.L.", progress: 78, status: "En Progreso", budget: "90.000,01 €" },
    { name: "Mantenimiento Eléctrico Preventivo", client: "Constructora Martínez S.L.", progress: 100, status: "Completado", budget: "24,20 €" },
  ]

  return (
    <div className="h-full w-full bg-[#06060a] flex overflow-hidden">
      <AnimatedGrid />
      
      {/* Sidebar */}
      <GlowSidebar isExpanded={sidebarExpanded} setIsExpanded={setSidebarExpanded} />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-[#0a0a10]/80 backdrop-blur-xl border-b border-gray-800/30 px-8 py-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 text-sm">Bienvenido de nuevo</p>
              <h1 className="text-2xl font-bold text-white">Dashboard</h1>
            </div>
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input
                  type="text"
                  placeholder="Buscar proyectos, clientes..."
                  className="bg-white/5 border border-gray-800/50 rounded-2xl pl-11 pr-4 py-3 text-sm text-white placeholder-gray-500 focus:border-teal-500/30 focus:bg-white/10 focus:outline-none w-80 transition-all"
                />
              </div>
              <button className="relative p-3 rounded-2xl bg-white/5 border border-gray-800/50 text-gray-400 hover:text-white hover:bg-white/10 transition-all">
                <Bell className="w-5 h-5" />
                <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-teal-500 rounded-full animate-pulse" />
              </button>
              <button className="p-3 rounded-2xl bg-white/5 border border-gray-800/50 text-gray-400 hover:text-white hover:bg-white/10 transition-all">
                <Settings className="w-5 h-5" />
              </button>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-auto p-8">
          {/* Stats */}
          <div className="grid grid-cols-4 gap-5 mb-8">
            {stats.map((stat, idx) => (
              <GradientBorderCard key={idx}>
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className={`p-3 rounded-xl ${
                      stat.color === "teal" ? "bg-teal-500/10" :
                      stat.color === "blue" ? "bg-blue-500/10" :
                      stat.color === "green" ? "bg-green-500/10" :
                      "bg-orange-500/10"
                    }`}>
                      <stat.icon className={`w-5 h-5 ${
                        stat.color === "teal" ? "text-teal-400" :
                        stat.color === "blue" ? "text-blue-400" :
                        stat.color === "green" ? "text-green-400" :
                        "text-orange-400"
                      }`} />
                    </div>
                    <button className="p-1.5 rounded-lg hover:bg-white/10 text-gray-500">
                      <MoreHorizontal className="w-4 h-4" />
                    </button>
                  </div>
                  <p className="text-3xl font-bold text-white mb-1">{stat.value}</p>
                  <p className="text-sm text-gray-500 mb-2">{stat.label}</p>
                  <p className="text-xs text-teal-400">{stat.change}</p>
                </div>
              </GradientBorderCard>
            ))}
          </div>

          {/* Big number card */}
          <GradientBorderCard className="mb-8">
            <div className="p-8 flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm uppercase tracking-wider mb-2">Facturación Total (Proyectos Aceptados)</p>
                <p className="text-5xl font-bold bg-gradient-to-r from-teal-400 to-cyan-400 bg-clip-text text-transparent">217.110,51 €</p>
                <p className="text-sm text-green-400 mt-2 flex items-center gap-1">
                  <TrendingUp className="w-4 h-4" />
                  +12.5% respecto al mes anterior
                </p>
              </div>
              <div className="w-32 h-32 relative">
                <div className="absolute inset-0 bg-gradient-to-br from-teal-500/20 to-cyan-500/20 rounded-full" />
                <div className="absolute inset-4 bg-[#0c0c14] rounded-full flex items-center justify-center">
                  <Euro className="w-12 h-12 text-teal-400" />
                </div>
              </div>
            </div>
          </GradientBorderCard>

          {/* Projects Table */}
          <GradientBorderCard>
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-white">Proyectos Recientes</h2>
                <button className="flex items-center gap-2 px-4 py-2 rounded-xl bg-teal-500/10 text-teal-400 hover:bg-teal-500/20 transition-colors text-sm font-medium">
                  Ver todos
                  <ArrowUpRight className="w-4 h-4" />
                </button>
              </div>
              <div className="space-y-4">
                {projects.map((project, idx) => (
                  <div key={idx} className="flex items-center gap-6 p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors">
                    <div className="flex-1">
                      <p className="font-medium text-white">{project.name}</p>
                      <p className="text-sm text-gray-500">{project.client}</p>
                    </div>
                    <div className="w-40">
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="text-gray-500">Progreso</span>
                        <span className="text-white">{project.progress}%</span>
                      </div>
                      <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full transition-all ${
                            project.progress === 100 ? "bg-green-500" : "bg-gradient-to-r from-teal-500 to-cyan-500"
                          }`}
                          style={{ width: `${project.progress}%` }}
                        />
                      </div>
                    </div>
                    <span className={`px-3 py-1.5 rounded-lg text-xs font-medium ${
                      project.status === "Completado" ? "bg-green-500/10 text-green-400" :
                      project.status === "En Progreso" ? "bg-teal-500/10 text-teal-400" :
                      "bg-yellow-500/10 text-yellow-400"
                    }`}>
                      {project.status}
                    </span>
                    <span className="text-white font-medium w-32 text-right">{project.budget}</span>
                  </div>
                ))}
              </div>
            </div>
          </GradientBorderCard>
        </main>
      </div>
    </div>
  )
}
