"use client"

import { useState } from "react"
import {
  LayoutDashboard,
  Users,
  FolderKanban,
  MessageSquare,
  UserCog,
  Ticket,
  LogOut,
  ChevronRight,
  TrendingUp,
  Clock,
  CheckCircle2,
  Euro,
  Zap,
  Bell,
  Search,
  Settings,
} from "lucide-react"

// Partículas flotantes sutiles
function SubtleParticles() {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none">
      {[...Array(30)].map((_, i) => (
        <div
          key={i}
          className="absolute rounded-full bg-teal-400/20"
          style={{
            width: Math.random() * 3 + 1 + "px",
            height: Math.random() * 3 + 1 + "px",
            left: Math.random() * 100 + "%",
            top: Math.random() * 100 + "%",
            animation: `floatUp ${Math.random() * 15 + 20}s linear infinite`,
            animationDelay: `-${Math.random() * 20}s`,
          }}
        />
      ))}
      <style jsx>{`
        @keyframes floatUp {
          0%, 100% { transform: translateY(0) translateX(0); opacity: 0; }
          10% { opacity: 0.6; }
          90% { opacity: 0.6; }
          100% { transform: translateY(-100vh) translateX(30px); opacity: 0; }
        }
      `}</style>
    </div>
  )
}

// Sidebar con borde neón animado
function AnimatedSidebar({ isExpanded, setIsExpanded }: { isExpanded: boolean; setIsExpanded: (v: boolean) => void }) {
  const navItems = [
    { icon: LayoutDashboard, label: "Dashboard", active: true },
    { icon: Users, label: "Clientes", active: false },
    { icon: FolderKanban, label: "Proyectos", active: false },
    { icon: MessageSquare, label: "Chat", active: false },
    { icon: UserCog, label: "Usuarios", active: false },
    { icon: Ticket, label: "Tickets", active: false },
  ]

  return (
    <div
      className={`relative h-full bg-[#0a0a12]/90 backdrop-blur-xl transition-all duration-300 ease-out flex flex-col ${
        isExpanded ? "w-64" : "w-20"
      }`}
      onMouseEnter={() => setIsExpanded(true)}
      onMouseLeave={() => setIsExpanded(false)}
    >
      {/* Borde neón animado */}
      <div className="absolute top-0 right-0 w-[2px] h-full overflow-hidden">
        <div className="absolute w-full h-full bg-gradient-to-b from-transparent via-teal-400 to-transparent animate-neon-flow" />
        <div className="absolute w-full h-full bg-teal-500/20" />
      </div>
      <style jsx>{`
        @keyframes neon-flow {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(100%); }
        }
        .animate-neon-flow {
          animation: neon-flow 3s linear infinite;
        }
      `}</style>

      {/* Logo */}
      <div className="p-4 border-b border-gray-800/50">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-teal-500 to-teal-600 flex items-center justify-center shrink-0 shadow-lg shadow-teal-500/20">
            <Zap className="w-6 h-6 text-white" />
          </div>
          <div className={`overflow-hidden transition-all duration-300 ${isExpanded ? "w-auto opacity-100" : "w-0 opacity-0"}`}>
            <h1 className="font-bold text-white whitespace-nowrap">
              <span className="text-teal-400">BLUEARC</span>ENERGY
            </h1>
            <p className="text-xs text-gray-500 whitespace-nowrap">Portal Interno</p>
          </div>
        </div>
      </div>

      {/* Navegación */}
      <nav className="flex-1 py-4 px-3">
        <div className="space-y-1">
          {navItems.map((item, idx) => (
            <button
              key={idx}
              className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-200 group ${
                item.active
                  ? "bg-teal-500/10 text-teal-400 border-l-2 border-teal-400"
                  : "text-gray-400 hover:bg-white/5 hover:text-white"
              }`}
            >
              <item.icon className={`w-5 h-5 shrink-0 ${item.active ? "text-teal-400" : ""}`} />
              <span className={`whitespace-nowrap transition-all duration-300 ${isExpanded ? "opacity-100" : "opacity-0 w-0"}`}>
                {item.label}
              </span>
              {item.active && isExpanded && (
                <ChevronRight className="w-4 h-4 ml-auto text-teal-400" />
              )}
            </button>
          ))}
        </div>
      </nav>

      {/* Usuario */}
      <div className="p-4 border-t border-gray-800/50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-500 to-cyan-500 flex items-center justify-center text-white font-bold shrink-0">
            M
          </div>
          <div className={`overflow-hidden transition-all duration-300 ${isExpanded ? "w-auto opacity-100" : "w-0 opacity-0"}`}>
            <p className="text-sm font-medium text-white whitespace-nowrap">Miguel Cárdenas</p>
            <p className="text-xs text-gray-500 whitespace-nowrap">Administrador</p>
          </div>
        </div>
        {isExpanded && (
          <button className="w-full mt-3 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors">
            <LogOut className="w-4 h-4" />
            <span className="text-sm">Cerrar Sesión</span>
          </button>
        )}
      </div>
    </div>
  )
}

// Stats Card con glassmorphism
function StatsCard({ icon: Icon, label, value, trend, color }: { icon: any; label: string; value: string; trend?: string; color: string }) {
  const colors: Record<string, string> = {
    teal: "from-teal-500/20 to-teal-600/10 border-teal-500/30 text-teal-400",
    blue: "from-blue-500/20 to-blue-600/10 border-blue-500/30 text-blue-400",
    green: "from-green-500/20 to-green-600/10 border-green-500/30 text-green-400",
    orange: "from-orange-500/20 to-orange-600/10 border-orange-500/30 text-orange-400",
    purple: "from-purple-500/20 to-purple-600/10 border-purple-500/30 text-purple-400",
  }

  return (
    <div className={`relative bg-gradient-to-br ${colors[color]} backdrop-blur-xl rounded-2xl p-5 border overflow-hidden group hover:scale-[1.02] transition-transform`}>
      <div className="absolute top-0 right-0 w-20 h-20 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2" />
      <div className="flex items-start justify-between relative z-10">
        <div>
          <p className="text-xs text-gray-400 uppercase tracking-wider mb-1">{label}</p>
          <p className="text-2xl font-bold text-white">{value}</p>
          {trend && (
            <p className="text-xs text-green-400 mt-1 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              {trend}
            </p>
          )}
        </div>
        <div className={`w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center`}>
          <Icon className="w-6 h-6" />
        </div>
      </div>
    </div>
  )
}

export default function PortalMockup1() {
  const [sidebarExpanded, setSidebarExpanded] = useState(false)

  const recentProjects = [
    { name: "Renovación Sistema Eléctrico Industrial", client: "Industrias García S.A.", status: "Pendiente", priority: "Media", date: "hace 19d" },
    { name: "Mantenimiento Eléctrico Preventivo", client: "Constructora Martínez S.L.", status: "Completado", priority: "Baja", date: "hace 58d" },
    { name: "Instalación Eléctrica Edificio Central", client: "Constructora Martínez S.L.", status: "En Progreso", priority: "Urgente", date: "hace 59d" },
  ]

  const recentBudgets = [
    { id: "PRE-1773232207763", project: "Renovación Sistema Eléctrico", amount: "24,20 €", date: "11/03/26", status: "Enviado" },
    { id: "PRES-2026-002", project: "Renovación Sistema Eléctrico", amount: "127.050,00 €", date: "16/02/26", status: "Aceptado" },
    { id: "PRE-1771241804589", project: "Renovación Sistema Eléctrico", amount: "36,30 €", date: "16/02/26", status: "Aceptado" },
  ]

  return (
    <div className="h-full w-full bg-[#050508] flex overflow-hidden">
      <SubtleParticles />
      
      {/* Sidebar */}
      <AnimatedSidebar isExpanded={sidebarExpanded} setIsExpanded={setSidebarExpanded} />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-[#0a0a12]/60 backdrop-blur-xl border-b border-gray-800/50 px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-white">Dashboard</h1>
              <p className="text-gray-500 text-sm">Bienvenido, Miguel Cárdenas</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input
                  type="text"
                  placeholder="Buscar..."
                  className="bg-white/5 border border-gray-800 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-gray-500 focus:border-teal-500/50 focus:outline-none w-64"
                />
              </div>
              <button className="relative p-2.5 rounded-xl bg-white/5 border border-gray-800 text-gray-400 hover:text-white hover:border-gray-700 transition-colors">
                <Bell className="w-5 h-5" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-teal-500 rounded-full" />
              </button>
              <button className="p-2.5 rounded-xl bg-white/5 border border-gray-800 text-gray-400 hover:text-white hover:border-gray-700 transition-colors">
                <Settings className="w-5 h-5" />
              </button>
              <span className="px-3 py-1.5 rounded-lg bg-teal-500/10 border border-teal-500/30 text-teal-400 text-xs font-medium">
                ADMINISTRADOR
              </span>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-auto p-8">
          {/* Stats Grid */}
          <div className="grid grid-cols-5 gap-4 mb-8">
            <StatsCard icon={FolderKanban} label="Proyectos" value="3" color="teal" />
            <StatsCard icon={Clock} label="En Progreso" value="1" color="blue" />
            <StatsCard icon={CheckCircle2} label="Completados" value="1" color="green" />
            <StatsCard icon={Ticket} label="Tickets Pendientes" value="0" color="orange" />
            <StatsCard icon={Euro} label="Facturación Total" value="217.110,51 €" trend="+12.5%" color="purple" />
          </div>

          {/* Two Column Layout */}
          <div className="grid grid-cols-3 gap-6">
            {/* Recent Activity */}
            <div className="col-span-2 bg-[#0a0a12]/60 backdrop-blur-xl rounded-2xl border border-gray-800/50 overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-800/50 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-teal-400" />
                  <h2 className="font-semibold text-white">Actividad Reciente</h2>
                </div>
                <a href="#" className="text-sm text-teal-400 hover:text-teal-300">Ver proyectos</a>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {recentProjects.map((project, idx) => (
                    <div key={idx} className="flex items-center justify-between p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors">
                      <div>
                        <p className="font-medium text-white">{project.name}</p>
                        <p className="text-sm text-gray-500">{project.client}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className={`px-2.5 py-1 rounded-lg text-xs font-medium ${
                          project.priority === "Urgente" ? "bg-red-500/10 text-red-400" :
                          project.priority === "Media" ? "bg-yellow-500/10 text-yellow-400" :
                          "bg-gray-500/10 text-gray-400"
                        }`}>
                          {project.priority}
                        </span>
                        <span className={`px-2.5 py-1 rounded-lg text-xs font-medium ${
                          project.status === "Completado" ? "bg-green-500/10 text-green-400" :
                          project.status === "En Progreso" ? "bg-teal-500/10 text-teal-400" :
                          "bg-yellow-500/10 text-yellow-400"
                        }`}>
                          {project.status}
                        </span>
                        <span className="text-xs text-gray-500 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {project.date}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Recent Budgets */}
            <div className="bg-[#0a0a12]/60 backdrop-blur-xl rounded-2xl border border-gray-800/50 overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-800/50 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Euro className="w-5 h-5 text-teal-400" />
                  <h2 className="font-semibold text-white">Últimos Presupuestos</h2>
                </div>
                <a href="#" className="text-sm text-teal-400 hover:text-teal-300">Ver todos</a>
              </div>
              <div className="p-4">
                <div className="space-y-3">
                  {recentBudgets.map((budget, idx) => (
                    <div key={idx} className="p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <p className="font-medium text-white text-sm">{budget.id}</p>
                          <p className="text-xs text-gray-500">{budget.project}</p>
                        </div>
                        <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                          budget.status === "Aceptado" ? "bg-green-500/10 text-green-400" : "bg-gray-500/10 text-gray-400"
                        }`}>
                          {budget.status}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-lg font-bold text-teal-400">{budget.amount}</span>
                        <span className="text-xs text-gray-500">{budget.date}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
