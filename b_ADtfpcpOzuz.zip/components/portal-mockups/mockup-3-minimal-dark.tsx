"use client"

import { useState } from "react"
import {
  LayoutDashboard,
  Users,
  FolderKanban,
  MessageSquare,
  UserCog,
  Ticket,
  LogOut,
  TrendingUp,
  Clock,
  CheckCircle2,
  Euro,
  Zap,
  Bell,
  Search,
  ChevronRight,
  Plus,
  Filter,
  Calendar,
  ArrowUp,
  ArrowDown,
} from "lucide-react"

// Efecto de ondas sutiles
function WaveEffect() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      <svg className="absolute bottom-0 left-0 w-full opacity-10" viewBox="0 0 1440 320">
        <path
          fill="rgba(45, 212, 191, 0.3)"
          d="M0,192L48,197.3C96,203,192,213,288,229.3C384,245,480,267,576,250.7C672,235,768,181,864,181.3C960,181,1056,235,1152,234.7C1248,235,1344,181,1392,154.7L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
        >
          <animate
            attributeName="d"
            dur="10s"
            repeatCount="indefinite"
            values="
              M0,192L48,197.3C96,203,192,213,288,229.3C384,245,480,267,576,250.7C672,235,768,181,864,181.3C960,181,1056,235,1152,234.7C1248,235,1344,181,1392,154.7L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z;
              M0,128L48,154.7C96,181,192,235,288,234.7C384,235,480,181,576,181.3C672,181,768,235,864,250.7C960,267,1056,245,1152,229.3C1248,213,1344,203,1392,197.3L1440,192L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z;
              M0,192L48,197.3C96,203,192,213,288,229.3C384,245,480,267,576,250.7C672,235,768,181,864,181.3C960,181,1056,235,1152,234.7C1248,235,1344,181,1392,154.7L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z
            "
          />
        </path>
      </svg>
    </div>
  )
}

// Sidebar ultra minimalista
function MinimalSidebar({ isExpanded, setIsExpanded }: { isExpanded: boolean; setIsExpanded: (v: boolean) => void }) {
  const navItems = [
    { icon: LayoutDashboard, label: "Dashboard", active: true },
    { icon: Users, label: "Clientes", active: false },
    { icon: FolderKanban, label: "Proyectos", active: false },
    { icon: MessageSquare, label: "Chat", active: false },
    { icon: UserCog, label: "Usuarios", active: false },
    { icon: Ticket, label: "Tickets", active: false },
  ]

  return (
    <div
      className={`relative h-full bg-[#09090b] transition-all duration-500 ease-out flex flex-col ${
        isExpanded ? "w-64" : "w-[72px]"
      }`}
      onMouseEnter={() => setIsExpanded(true)}
      onMouseLeave={() => setIsExpanded(false)}
    >
      {/* Línea neón lateral con pulso */}
      <div className="absolute top-0 right-0 w-px h-full bg-gray-800">
        <div className="absolute inset-0 bg-gradient-to-b from-teal-500/0 via-teal-400 to-teal-500/0 animate-pulse-line" />
      </div>
      <style jsx>{`
        @keyframes pulse-line {
          0%, 100% { opacity: 0.3; transform: scaleY(0.5) translateY(-25%); }
          50% { opacity: 1; transform: scaleY(1) translateY(0); }
        }
        .animate-pulse-line {
          animation: pulse-line 3s ease-in-out infinite;
        }
      `}</style>

      {/* Logo minimalista */}
      <div className="h-20 flex items-center justify-center border-b border-gray-800/50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-teal-500 flex items-center justify-center">
            <Zap className="w-5 h-5 text-black" />
          </div>
          <span className={`font-bold text-white whitespace-nowrap transition-all duration-500 ${isExpanded ? "opacity-100 w-auto" : "opacity-0 w-0 overflow-hidden"}`}>
            <span className="text-teal-400">BA</span>Energy
          </span>
        </div>
      </div>

      {/* Nav items */}
      <nav className="flex-1 py-6">
        <div className="space-y-1 px-3">
          {navItems.map((item, idx) => (
            <button
              key={idx}
              className={`w-full flex items-center gap-3 h-12 px-3 rounded-lg transition-all duration-200 ${
                item.active
                  ? "bg-teal-500/10 text-teal-400"
                  : "text-gray-500 hover:text-white hover:bg-white/5"
              }`}
            >
              <item.icon className="w-5 h-5 shrink-0" />
              <span className={`whitespace-nowrap transition-all duration-500 ${isExpanded ? "opacity-100" : "opacity-0"}`}>
                {item.label}
              </span>
              {item.active && isExpanded && (
                <div className="ml-auto w-1.5 h-1.5 rounded-full bg-teal-400" />
              )}
            </button>
          ))}
        </div>
      </nav>

      {/* User section */}
      <div className="p-3 border-t border-gray-800/50">
        <div className={`flex items-center gap-3 p-2 rounded-lg ${isExpanded ? "bg-white/5" : ""}`}>
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-teal-400 to-cyan-400 flex items-center justify-center text-black font-bold text-sm shrink-0">
            MC
          </div>
          <div className={`transition-all duration-500 ${isExpanded ? "opacity-100 w-auto" : "opacity-0 w-0 overflow-hidden"}`}>
            <p className="text-sm font-medium text-white whitespace-nowrap">Miguel C.</p>
            <p className="text-xs text-gray-500 whitespace-nowrap">Admin</p>
          </div>
          {isExpanded && (
            <button className="ml-auto p-1.5 text-gray-500 hover:text-red-400 transition-colors">
              <LogOut className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

export default function PortalMockup3() {
  const [sidebarExpanded, setSidebarExpanded] = useState(false)

  const quickStats = [
    { label: "Proyectos", value: "3", icon: FolderKanban, trend: "up", trendValue: "2" },
    { label: "En Progreso", value: "1", icon: Clock, trend: null, trendValue: null },
    { label: "Completados", value: "1", icon: CheckCircle2, trend: "up", trendValue: "1" },
    { label: "Tickets", value: "0", icon: Ticket, trend: "down", trendValue: "3" },
  ]

  const recentActivity = [
    { type: "project", title: "Instalación Eléctrica Edificio Central", action: "actualizado", time: "hace 2h", user: "Miguel" },
    { type: "budget", title: "PRES-2026-002 aprobado", action: "127.050,00 €", time: "hace 5h", user: "Sistema" },
    { type: "ticket", title: "Nuevo ticket de Industrias García", action: "asignado", time: "hace 1d", user: "Juan" },
    { type: "client", title: "Constructora Martínez S.L.", action: "nuevo proyecto", time: "hace 2d", user: "Miguel" },
  ]

  return (
    <div className="h-full w-full bg-[#09090b] flex overflow-hidden">
      <WaveEffect />
      
      {/* Sidebar */}
      <MinimalSidebar isExpanded={sidebarExpanded} setIsExpanded={setSidebarExpanded} />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header ultra limpio */}
        <header className="h-20 border-b border-gray-800/50 px-8 flex items-center justify-between">
          <div className="flex items-center gap-8">
            <div>
              <h1 className="text-xl font-semibold text-white">Dashboard</h1>
              <p className="text-sm text-gray-500">Resumen general del sistema</p>
            </div>
            <div className="h-8 w-px bg-gray-800" />
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Calendar className="w-4 h-4" />
              <span>Abril 2026</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-600" />
              <input
                type="text"
                placeholder="Buscar..."
                className="w-56 bg-transparent border border-gray-800 rounded-lg pl-10 pr-4 py-2 text-sm text-white placeholder-gray-600 focus:border-teal-500/50 focus:outline-none transition-colors"
              />
            </div>
            <button className="relative p-2 text-gray-500 hover:text-white transition-colors">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-teal-500 rounded-full" />
            </button>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-auto">
          <div className="p-8">
            {/* Welcome banner */}
            <div className="mb-8 p-6 rounded-2xl bg-gradient-to-r from-teal-500/10 to-cyan-500/5 border border-teal-500/20">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold text-white mb-1">Bienvenido, Miguel</h2>
                  <p className="text-gray-400">Tienes 2 tareas pendientes y 1 proyecto en progreso</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-500 mb-1">Facturación Total</p>
                  <p className="text-3xl font-bold text-teal-400">217.110,51 €</p>
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-4 gap-4 mb-8">
              {quickStats.map((stat, idx) => (
                <div key={idx} className="p-5 rounded-xl border border-gray-800/50 bg-[#0c0c0f] hover:border-gray-700/50 transition-colors group">
                  <div className="flex items-center justify-between mb-4">
                    <stat.icon className="w-5 h-5 text-gray-500 group-hover:text-teal-400 transition-colors" />
                    {stat.trend && (
                      <span className={`flex items-center gap-1 text-xs ${stat.trend === "up" ? "text-green-400" : "text-red-400"}`}>
                        {stat.trend === "up" ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />}
                        {stat.trendValue}
                      </span>
                    )}
                  </div>
                  <p className="text-3xl font-bold text-white mb-1">{stat.value}</p>
                  <p className="text-sm text-gray-500">{stat.label}</p>
                </div>
              ))}
            </div>

            {/* Two columns */}
            <div className="grid grid-cols-5 gap-6">
              {/* Activity */}
              <div className="col-span-3 rounded-xl border border-gray-800/50 bg-[#0c0c0f]">
                <div className="p-5 border-b border-gray-800/50 flex items-center justify-between">
                  <h3 className="font-medium text-white">Actividad Reciente</h3>
                  <button className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-teal-400 transition-colors">
                    <Filter className="w-4 h-4" />
                    Filtrar
                  </button>
                </div>
                <div className="p-5">
                  <div className="space-y-4">
                    {recentActivity.map((item, idx) => (
                      <div key={idx} className="flex items-start gap-4 p-3 rounded-lg hover:bg-white/5 transition-colors">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${
                          item.type === "project" ? "bg-teal-500/10 text-teal-400" :
                          item.type === "budget" ? "bg-green-500/10 text-green-400" :
                          item.type === "ticket" ? "bg-orange-500/10 text-orange-400" :
                          "bg-blue-500/10 text-blue-400"
                        }`}>
                          {item.type === "project" ? <FolderKanban className="w-5 h-5" /> :
                           item.type === "budget" ? <Euro className="w-5 h-5" /> :
                           item.type === "ticket" ? <Ticket className="w-5 h-5" /> :
                           <Users className="w-5 h-5" />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-white truncate">{item.title}</p>
                          <p className="text-xs text-gray-500">{item.action} por {item.user}</p>
                        </div>
                        <span className="text-xs text-gray-600 whitespace-nowrap">{item.time}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="col-span-2 space-y-6">
                <div className="rounded-xl border border-gray-800/50 bg-[#0c0c0f] p-5">
                  <h3 className="font-medium text-white mb-4">Acciones Rápidas</h3>
                  <div className="space-y-2">
                    {[
                      { label: "Nuevo Proyecto", icon: FolderKanban },
                      { label: "Nuevo Cliente", icon: Users },
                      { label: "Nuevo Presupuesto", icon: Euro },
                    ].map((action, idx) => (
                      <button key={idx} className="w-full flex items-center gap-3 p-3 rounded-lg border border-gray-800/50 hover:border-teal-500/30 hover:bg-teal-500/5 text-gray-400 hover:text-teal-400 transition-all group">
                        <div className="w-8 h-8 rounded-lg bg-gray-800/50 group-hover:bg-teal-500/10 flex items-center justify-center transition-colors">
                          <Plus className="w-4 h-4" />
                        </div>
                        <span className="text-sm">{action.label}</span>
                        <ChevronRight className="w-4 h-4 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="rounded-xl border border-gray-800/50 bg-[#0c0c0f] p-5">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-medium text-white">Este Mes</h3>
                    <TrendingUp className="w-4 h-4 text-green-400" />
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">Presupuestos enviados</span>
                      <span className="text-sm font-medium text-white">4</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">Presupuestos aceptados</span>
                      <span className="text-sm font-medium text-green-400">3</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">Tasa de conversión</span>
                      <span className="text-sm font-medium text-teal-400">75%</span>
                    </div>
                    <div className="h-px bg-gray-800 my-2" />
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-500">Total facturado</span>
                      <span className="text-lg font-bold text-white">127.110,50 €</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
