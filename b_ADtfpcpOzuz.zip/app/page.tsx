"use client"

import { useState } from "react"
import PortalMockup1 from "@/components/portal-mockups/mockup-1-glassmorphism"
import PortalMockup2 from "@/components/portal-mockups/mockup-2-gradient-cards"
import PortalMockup3 from "@/components/portal-mockups/mockup-3-minimal-dark"

const mockups = [
  { id: 1, name: "Glassmorphism", description: "Cards translúcidas con blur y partículas flotantes" },
  { id: 2, name: "Gradient Cards", description: "Cards con bordes gradiente y grid animado" },
  { id: 3, name: "Minimal Dark", description: "Ultra minimalista con ondas sutiles" },
]

export default function PortalMockupsShowcase() {
  const [activeMockup, setActiveMockup] = useState(1)

  return (
    <div className="h-screen w-full bg-[#050508] flex flex-col overflow-hidden">
      {/* Selector de Mockups */}
      <div className="bg-[#0a0a0f]/90 backdrop-blur-xl border-b border-teal-500/20 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div>
              <h1 className="text-lg font-bold text-white">
                <span className="text-teal-400">BLUEARC</span>ENERGY
              </h1>
              <p className="text-xs text-gray-500">Portal Interno - Mockups Dashboard</p>
            </div>
            <div className="h-8 w-px bg-gray-800" />
            <div className="flex gap-2">
              {mockups.map((mockup) => (
                <button
                  key={mockup.id}
                  onClick={() => setActiveMockup(mockup.id)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    activeMockup === mockup.id
                      ? "bg-teal-500 text-white shadow-lg shadow-teal-500/25"
                      : "bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white border border-gray-800"
                  }`}
                >
                  {mockup.id}. {mockup.name}
                </button>
              ))}
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs text-gray-500">Mockup activo</p>
            <p className="text-sm text-teal-400 font-medium">{mockups[activeMockup - 1].description}</p>
          </div>
        </div>
      </div>

      {/* Mockup Activo - Full Height */}
      <div className="flex-1 overflow-hidden">
        {activeMockup === 1 && <PortalMockup1 />}
        {activeMockup === 2 && <PortalMockup2 />}
        {activeMockup === 3 && <PortalMockup3 />}
      </div>

      {/* Footer info */}
      <div className="bg-[#0a0a0f]/90 backdrop-blur-xl border-t border-gray-800/50 px-6 py-2 flex items-center justify-between">
        <p className="text-xs text-gray-600">
          Sidebar colapsable: solo iconos por defecto, se expande al pasar el ratón
        </p>
        <p className="text-xs text-gray-600">
          Borde neón teal animado en el sidebar
        </p>
      </div>
    </div>
  )
}
